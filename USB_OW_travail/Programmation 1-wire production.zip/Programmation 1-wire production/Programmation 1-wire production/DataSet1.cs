﻿namespace Programmation_1_wire_production {
    
    
    public partial class DataSet1 {
        partial class Acc_nameDataTable
        {
        }
    }
}
